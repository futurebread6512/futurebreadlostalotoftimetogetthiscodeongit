package com.example.fragment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {
    FrameLayout container;
    Button currentTask, finishtask, period;

    FragmentManager fm;
    FragmentTransaction ft;
    CurrentTaskfragment ctf;
    FinishdTaskfragment ftf;
    PeriodFragment prf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        container=findViewById(R.id.contaner);
        currentTask=findViewById(R.id.buttonTask);
        finishtask=findViewById(R.id.butttonEndedTask);
        period = findViewById(R.id.butttonregular);

        fm = getSupportFragmentManager();
        ft = fm.beginTransaction();
        ctf = new CurrentTaskfragment();
        ftf = new FinishdTaskfragment();
        prf = new PeriodFragment();
        ft.add(R.id.contaner, ctf);
        ft.commit();

        currentTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ft = fm.beginTransaction();
                ft.replace(R.id.contaner, ctf);
                ft.commit();
            }
        });
        finishtask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ft = fm.beginTransaction();
                ft.replace(R.id.contaner, ftf);
                ft.commit();
            }
        });
        period.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ft = fm.beginTransaction();
                ft.replace(R.id.contaner, prf);
                ft.commit();
            }
        });
    }
}